import string
import random
import os

# Ask the user for the number of nitro codes to generate
num_codes = int(input("Enter the number of nitro codes to generate: "))

# Generate nitro codes
nitro_codes = [random.choices(string.ascii_letters + string.digits, k=16) for _ in range(num_codes)]

# Function to check the validity of a nitro code
def check_validity(code):
    if len(code) != 16:
        return False
    if not any(char.isdigit() for char in code):
        return False
    return True

# Create the necessary text files
with open("Codes.txt", "w") as file:
    pass

with open("WorkingCodes.txt", "w") as file:
    pass

# Save the generated nitro codes in the respective text files
for code in nitro_codes:
    if check_validity(code):
        with open("WorkingCodes.txt", "a") as file:
            file.write("".join(code) + "\n")
    else:
        with open("Codes.txt", "a") as file:
            file.write("".join(code) + "\n")

print("Nitro Codes Generated Successfully, Please Check Codes.txt Or WorkingCodes.txt")