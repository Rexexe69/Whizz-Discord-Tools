import os
import string
import secrets
import requests

# Check if tokens.txt file exists
if not os.path.exists('tokens.txt'):
    open('tokens.txt', 'w').close()

# Function to generate Discord tokens
def generate_tokens(num_tokens):
    with open('tokens.txt', 'a') as file:
        for _ in range(num_tokens):
            token = ''.join(secrets.choice(string.ascii_letters + string.digits) for _ in range(59))
            file.write(f'{token}\n')

# Function to check if a token works
def check_token(token):
    headers = {'Authorization': token}
    try:
        response = requests.get('https://discord.com/api/v6/users/@me', headers=headers)
        if response.status_code == 200:
            return True
        else:
            return False
    except:
        return False

# Get number of tokens to generate
num_tokens = int(input("Enter the number of tokens to generate: "))

# Generate and save tokens
generate_tokens(num_tokens)

# Check and save working tokens
if not os.path.exists('workingtokens.txt'):
    open('workingtokens.txt', 'w').close()

with open('tokens.txt', 'r') as file:
    lines = file.readlines()

with open('workingtokens.txt', 'a') as file:
    for line in lines:
        token = line.strip()
        if check_token(token):
            file.write(f'{token}\n')